const products = Array.from({length: 20}, (_, i) => ({
  id: i + 1,
  name: `منتج رقم ${i + 1}`,
  price: (i + 1) * 10,
  image: "https://via.placeholder.com/200x150"
}));

const productList = document.getElementById('product-list');
const cartItems = document.getElementById('cart-items');

if (productList) {
  products.forEach(product => {
    const div = document.createElement('div');
    div.className = 'product';
    div.innerHTML = `
      <a href="product.html?id=${product.id}">
        <img src="${product.image}" alt="${product.name}" />
        <h3>${product.name}</h3>
      </a>
      <p>السعر: ${product.price} ريال</p>
      <button onclick="addToCart('${product.name}', ${product.price})">أضف إلى السلة</button>
    `;
    productList.appendChild(div);
  });
}

function addToCart(name, price) {
  const li = document.createElement('li');
  li.textContent = `${name} - ${price} ريال`;
  cartItems.appendChild(li);
}

function goToCheckout() {
  window.location.href = "checkout.html";
}